const display = document.getElementById("display");
let ans = 0; 

function clearDisplay() {
    display.value = "";
}

function deleteChar() {
    display.value = display.value.slice(0, -1);
}

function append(character) {
    display.value += character;
}

function calculate() {
    try {
        let expression = display.value
            .replace(/Ans/g, ans)
            .replace(/sin/g, 'Math.sin')
            .replace(/cos/g, 'Math.cos')
            .replace(/tan/g, 'Math.tan')
            .replace(/√/g, 'Math.sqrt')
            .replace(/log/g, 'Math.log10')
            .replace(/ln/g, 'Math.log')
            .replace(/π/g, 'Math.PI')
            .replace(/e/g, 'Math.E');

        ans = eval(expression); 
        display.value = ans;
    } catch (error) {
        display.value = "Error";
    }
}
