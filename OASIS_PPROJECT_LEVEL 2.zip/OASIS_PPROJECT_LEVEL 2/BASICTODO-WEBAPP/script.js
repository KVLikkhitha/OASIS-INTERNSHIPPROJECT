const taskInput = document.getElementById("taskInput");
const descriptionInput = document.getElementById("descriptionInput");
const addButton = document.getElementById("addButton");
const taskList = document.getElementById("taskList");
const progressFill = document.getElementById("progressFill");
const progressText = document.getElementById("progressText");
const celebration = document.getElementById("celebration");
 
let tasks = [];
let editingTaskId = null;
 
function addTask(title, description) {
    if (editingTaskId) {
        // Update existing task
        const task = tasks.find(t => t.id === editingTaskId);
        task.title = title;
        task.description = description;
        editingTaskId = null;
        addButton.textContent = "Add Task";
    } else {
        // Add new task
        const task = { id: Date.now(), title, description, completed: false };
        tasks.push(task);
    }
 
    taskInput.value = "";
    descriptionInput.value = "";
    renderTasks();
    updateProgress();
}
 
function renderTasks() {
    taskList.innerHTML = '';
    tasks.forEach(task => {
        const taskItem = document.createElement('div');
        taskItem.className = 'task-item';
        if (task.completed) taskItem.classList.add('completed');
 
        const taskDetails = document.createElement('div');
        taskDetails.className = 'task-details';
 
        const taskTitle = document.createElement('span');
        taskTitle.textContent = task.title;
        taskDetails.appendChild(taskTitle);
 
        const taskDescription = document.createElement('small');
        taskDescription.textContent = task.description;
        taskDetails.appendChild(taskDescription);
 
        const actions = document.createElement('div');
        actions.className = 'task-actions';
 
        const completeButton = document.createElement('button');
        completeButton.innerHTML = '✔️';
        completeButton.onclick = () => toggleTaskCompletion(task.id);
 
        const editButton = document.createElement('button');
        editButton.innerHTML = '✏️';
        editButton.onclick = () => editTask(task);
 
        const deleteButton = document.createElement('button');
        deleteButton.innerHTML = '🗑️';
        deleteButton.onclick = () => deleteTask(task.id);
 
        actions.append(completeButton, editButton, deleteButton);
        taskItem.append(taskDetails, actions);
        taskList.appendChild(taskItem);
    });
}
 
function toggleTaskCompletion(taskId) {
    const task = tasks.find(t => t.id === taskId);
    if (task) {
        task.completed = !task.completed;
        renderTasks();
        updateProgress();
    }
}
 
function deleteTask(taskId) {
    tasks = tasks.filter(task => task.id !== taskId);
    renderTasks();
    updateProgress();
}
 
function editTask(task) {
    taskInput.value = task.title;
    descriptionInput.value = task.description;
    editingTaskId = task.id;
    addButton.textContent = "Update Task";
}
 
function updateProgress() {
    const completedTasks = tasks.filter(task => task.completed).length;
    const totalTasks = tasks.length;
    const progress = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
 
    progressFill.style.width = `${progress}%`;
    progressText.textContent = `${completedTasks}/${totalTasks}`;
 
    if (completedTasks === totalTasks && totalTasks > 0) {
        showCelebration();
    } else {
        hideCelebration();
    }
}
 
function showCelebration() {
    celebration.style.display = 'block';
    setTimeout(hideCelebration, 2000);
}
 
function hideCelebration() {
    celebration.style.display = 'none';
}
 
addButton.addEventListener("click", () => {
    const title = taskInput.value.trim();
    const description = descriptionInput.value.trim();
    if (title) {
        addTask(title, description);
    }
});
 
renderTasks();
 